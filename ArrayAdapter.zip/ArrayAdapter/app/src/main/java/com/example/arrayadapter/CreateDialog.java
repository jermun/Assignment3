package com.example.arrayadapter;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import java.util.Calendar;
import java.util.Date;

public class CreateDialog extends AppCompatDialogFragment {
    public MainActivity mainActivity;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){
        final AlertDialog.Builder aD = new AlertDialog.Builder(getActivity());
        aD.setTitle("ATTENTION")
                .setMessage("ADD TIME?")
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
                aD.setPositiveButton("YES", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i){
                        Toast.makeText(getContext(),"NICE!", Toast.LENGTH_SHORT).show();
                        mainActivity.clickedYes();
                    }
                });


        return aD.create();
    }
}
