package com.example.arrayadapter;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Date;

public class ListAdapter extends ArrayAdapter<Date> {


    private int lLayout;
    private ArrayList<Date> list;
    private LayoutInflater inflater;
    private Context context;

    public ListAdapter(@NonNull Context context, int resource,
        int textViewResourceId, @NonNull ArrayList<Date> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        lLayout = resource;
        list = objects;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @NonNull
    @Override
    public View getView(final int pos, @Nullable View cView, @NonNull ViewGroup parent) {

        View v;
        if (cView == null) {
            v = LayoutInflater.from(context).inflate(R.layout.adapter, parent, false);
            ((TextView) v.findViewById(R.id.clock)).setText(list.get(pos).toString());
            v.findViewById(R.id.removeButton).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    list.remove(pos);
                    notifyDataSetChanged();
                }
            });
        } else {
            v = cView;
        }
        return v;
    }

    public class ViewHolder {
        private TextView textView;
        private Button button;

        public ViewHolder(View v){
            button = v.findViewById(R.id.removeButton);
        }
    }
}
