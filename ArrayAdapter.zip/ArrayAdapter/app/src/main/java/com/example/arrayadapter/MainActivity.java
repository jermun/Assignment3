package com.example.arrayadapter;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    private ListAdapter adapter;
    private ArrayList<Date> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listview = findViewById(R.id.listView);
        adapter = new ListAdapter(this, R.layout.adapter, R.id.clock, list);
        listview.setAdapter(adapter);

        findViewById(R.id.timeButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
                adapter.notifyDataSetChanged();
            }
        });
    }

    public void openDialog(){
        CreateDialog createDialog = new CreateDialog();
        createDialog.show(getSupportFragmentManager(), "This is a dialog");
    }

    public void clickedYes()
    {
        Date time = Calendar.getInstance().getTime();
        list.add(time);
    }

}


